# tooth Xray second Worke > 2025-01-20 10:22pm
https://universe.roboflow.com/abdul-aziz-dgqpw/tooth-xray-second-worke

Provided by a Roboflow user
License: CC BY 4.0

